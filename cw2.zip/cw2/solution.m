%Candidate Number: 21908
theKey = PermutationKey('VFCPKGQNHEUYZSOAWBDRXMITJL');
%Solution key to the text 'secret' defined in 'ciphertext.m'